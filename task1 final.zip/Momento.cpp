#include "Momento.h"

using namespace std;

Momento::Momento()
{
}

Momento::~Momento()
{
}